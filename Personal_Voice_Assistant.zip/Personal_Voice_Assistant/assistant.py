import speech_recognition as sr
import pyttsx3
import datetime
import webbrowser
import os

engine = pyttsx3.init()

def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

def take_command():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)

        try:
            audio = recognizer.listen(source)

            command = recognizer.recognize_google(audio)
            print("You said:", command)

            return command.lower()

        except:
            return ""

speak("Hello, I am your personal voice assistant.")

while True:

    command = take_command()

    if command == "":
        continue

    elif "hello" in command:
        speak("Hello, how can I help you?")

    elif "time" in command:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The current time is {current_time}")

    elif "open google" in command:
        webbrowser.open("https://www.google.com")
        speak("Opening Google")

    elif "open youtube" in command:
        webbrowser.open("https://www.youtube.com")
        speak("Opening YouTube")

    elif "open calculator" in command:
        os.system("calc")
        speak("Opening Calculator")

    elif "open notepad" in command:
        os.system("notepad")
        speak("Opening Notepad")

    elif "search" in command:
        search_query = command.replace("search", "")
        webbrowser.open(
            f"https://www.google.com/search?q={search_query}"
        )
        speak("Searching on Google")

    elif "exit" in command:
        speak("Goodbye")
        break

    else:
        speak("Sorry, command not recognized.")